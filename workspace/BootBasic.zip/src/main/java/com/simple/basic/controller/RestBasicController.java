package com.simple.basic.controller;

import com.simple.basic.command.SimpleVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import javax.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@RestController//일반컨트롤러랑은 다른의미 - return에 담기는 데이터가 요총한 곳으로 응답함
//@Controller + ResponseBody = RestController의 합성어
public class RestBasicController {

    //    @ResponseBody //굳이 안 적어도 됨
    @GetMapping("/hello")
    public String hello() {
        return "<h3>hello world</h3>";
        //return 앞에 실리는 게 dispathture로 안가고 요청한 주소로 보내버림
    }

    //데이터를 보내는 방법
    //1. 객체반환
    //ResponseBody와 Json-databind 라이브러리가 자동으로 해줌
    @GetMapping("/bye")
    public SimpleVO bye() {
        return new SimpleVO(5, "asd", LocalDateTime.now());
    }

    //2. 맵을 반환
    @GetMapping("/getMap")
    public Map<String, Object> getMap() {
        Map<String, Object> map = new HashMap<>();
        map.put("name", "손뉴경");
        map.put("age", 20);
        map.put("data", new SimpleVO(1, "홍길동", LocalDateTime.now()));

        return map; //JSON으로 바뀜
    }

    //3. 리스트로 반환
    @GetMapping("/getList")
    public List<SimpleVO> getList() {
        List<SimpleVO> list = new ArrayList<>();
        list.add(new SimpleVO(1, "김아나", LocalDateTime.now()));
        list.add(new SimpleVO(2, "김둠피", LocalDateTime.now()));
        return list;
    }

    //값을 받는 방법
    //요청의 다양한 타입 get
    //@RequestParam이나, VO를 통해서 받을 수 있음

    //http://localhost:8181/getData?name=홍길동&sno=1
    @GetMapping("/getData")
    public String getData(@RequestParam("name") String name,
                          @RequestParam("sno") int sno,
                          HttpServletRequest request) {

        log.info(request.getRemoteAddr());

        log.info(name + ", " + sno);

        return "success";
    }

    //http://localhost:8181/getData3?name=배고파&sno=1
    @GetMapping("/getData2")
    public String getData(SimpleVO vo) {
        log.info(vo.toString());
        return "success";
    }

    //http://localhost:8181/getData3/값/값
    @GetMapping("/getData3/{name}/{sno}")
    public String getData3(@PathVariable("name") String name,
                           @PathVariable("sno") int sno) {
        log.info(name + ", " + sno);
        return "success";
    }

    /// ////////////////////////////////////////////////
    //post방식으로 데이터 받기
    //상대방이 데이터를 보내는 contentType을 지정함(form타입, JSON타입)

    //보내는 입장이 form형식으로 보내는 경우 반드시 써줘야함
//    @PostMapping("/getForm")
//    public String getForm(SimpleVO vo) {
//        log.info(vo.toString());
//        return "success";
//    }
    @PostMapping("/getForm")
    public String getForm(@RequestParam("name") String name,
                          @RequestParam("sno") int sno) {
        log.info(name + ", " + sno);
        return "success";
    }

    //보내는 입장이 JSON타입으로 보내는 경우
    //@RequestBody -> JSON 데이터를 Object에 맵핑을 시킴
//    @PostMapping("/getJson")
//    public String getJson(@RequestBody SimpleVO vo){
//        log.info(vo.toString());
//        return "success";
//    }

    @PostMapping("/getJson")
    public String getJson(@RequestBody Map<String, Object> map) {
        log.info(map.toString());
        return "success";
    }

    /// /////////////////////////////////////////////////
    //produces - 서버에서 보내는 타입에 대한 명세 (아무 것도 안 적으면 기본 JSON타입)
    //consumers - "너 반드시 이렇게 데이터 보내" 명세 (너 a 방법으로 안 보내면 난 안받을거야 ㅅㄱ)
    @PostMapping(value = "/getResult", produces = "text/plain", consumes = "text/plain")
    public String getResult(@RequestBody String str) {
        log.info(str);
        return "<h3>안녕하세요</h3>";
    }

    /// /////////////////////////////////////////////
    //응답 문서 작성하기 ResponseEntity<보낼데이터타입>
    @PostMapping("/createEntity")
    public ResponseEntity<SimpleVO> createEntity() {

        SimpleVO vo = new SimpleVO(2, "개졸려", LocalDateTime.now());

        //응답문서에 헤더에 대한 내역을 추가할 수 있음.
        HttpHeaders headers = new HttpHeaders();
        headers.add("content-type", "application/json");
        headers.add("authorization", "JSON WEB TOKEN");
        headers.add("Access-control-allow-origin", "*");

        return new ResponseEntity<>(vo, headers, HttpStatus.OK);
    }


    /// ///////////////////////////////////////////////
    // 명세서에 맞춰 작성 후 부메랑으로 호출
    /*
    요청 주소 - /api/v1/getData
    메서드 - get
    클라이언트에서 보내는 데이터 - num, name
    서버에서 응답하는 데이터는 SimpleVO
    responseEntity로 응답
     */
    @GetMapping(value = "/api/v1/getData", produces = "application/json")
    public ResponseEntity<SimpleVO> getData(@RequestParam("num") int num,
                                            @RequestParam("name") String name) {

        // 데이터 처리 후 SimpleVO 객체 생성
        SimpleVO vo = new SimpleVO(1, "asd", LocalDateTime.now());
        log.info(num + ", " + name);

        // ResponseEntity로 응답 반환
        return new ResponseEntity<>(vo, HttpStatus.OK);
    }


    /*
    요청주소 - /api/v1/getInfo
    메서드 - post
    클라이언트에서 보내는 데이터 - JSON타입의 num, name
    서버에서 응답하는 데이터는 - List<SimpleVO>
    responseEntity로 응답
     */
    @PostMapping("/api/v1/getInfo")
    public ResponseEntity<List<SimpleVO>> getInfo(@RequestBody SimpleVO vo) {
        List<SimpleVO> list = new ArrayList<>();
        list.add(new SimpleVO(1, "김아나", LocalDateTime.now()));
        list.add(new SimpleVO(2, "김둠피", LocalDateTime.now()));
        return new ResponseEntity<>(list, HttpStatus.OK);
    }




}


//@RequestBody = JSON으로 들어오는 데이터 JAVA OBJ로 싹 바꿔줌
