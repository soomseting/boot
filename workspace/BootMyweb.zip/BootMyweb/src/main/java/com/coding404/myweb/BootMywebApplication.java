package com.coding404.myweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootMywebApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootMywebApplication.class, args);
	}

}
